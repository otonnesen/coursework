import numpy as np

from config import get_config, print_usage, print_config
from utils.cifar10 import load_data
from utils.features import extract_h_histogram, extract_hog
from utils.preprocess import normalize
from utils.regularizor import l2_grad, l2_loss
from utils import loss_func, grad_func

import solution

config, _ = get_config()

data_trva, y_trva = load_data(config.data_dir, "train")

data_te, y_te = load_data(config.data_dir, "test")

x_trva = solution.compute_feature(data_trva, config)
x_te = solution.compute_feature(data_te, config)

x_tr = x_trva
x_va = x_te
y_tr = y_trva
y_va = y_te

## train

x_tr_n, x_tr_mean, x_tr_range = normalize(x_tr)
x_va_n, _, _ = normalize(x_va, x_tr_mean, x_tr_range)

num_class = 10

W = (np.random.rand(x_tr_n.shape[1], num_class)-0.5)*0.002

b = np.zeros(num_class)

pred = np.argmax(np.matmul(x_va_n, W) + b, axis=1)
acc = np.mean(pred == y_va)

x_b = x_tr_n
y_b = y_tr

loss_cur, temp_b, pred_b = loss_func.logistic_regression(W, b, x_b, y_b)

dW, db = grad_func.logistic_regression_grad(temp_b, x_b, y_b)
loss_c = temp_b
x = x_b
y = y_b
